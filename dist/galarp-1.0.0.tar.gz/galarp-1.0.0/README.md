GalaRP (Gala + RP) is an analytical framework for gaseous evolution under ram pressure.
